# Foto2Excel — Proyek Android awal

Aplikasi Android berbahasa Indonesia untuk memilih gambar, membaca teks dengan ML Kit OCR, mengedit hasil teks, menghitung total angka sederhana, menyimpan riwayat lokal, dan mengekspor isi ke `.xlsx`.

## Membuka proyek
1. Ekstrak ZIP ini.
2. Buka folder `Foto2Excel_Android` di Android Studio versi terbaru.
3. Pastikan JDK 17 terpasang dan izinkan Gradle mengunduh dependensi.
4. Jalankan pada perangkat Android atau emulator.

## Membuat APK
Di Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Ini adalah proyek sumber awal, bukan APK yang sudah dikompilasi.
- OCR ML Kit Latin ditujukan terutama untuk teks cetak. Tulisan tangan dapat terbaca tidak konsisten; hasil harus diperiksa manual. Untuk pengenalan tulisan tangan yang lebih kuat mungkin diperlukan layanan OCR khusus.
- Ekspor Excel saat ini memasukkan baris yang dipisahkan tab, koma, titik koma, garis vertikal, atau beberapa spasi. Untuk foto tabel yang kompleks, rapikan hasil teks dahulu agar kolom tepat.
- Fitur hitung total adalah penjumlahan sederhana per posisi kolom; periksa agar nomor urut/tanggal tidak ikut dijumlahkan.
- Ini belum melalui pengujian build pada perangkat nyata. Versi Android Studio/Gradle mungkin memerlukan penyesuaian dependensi.

## Build APK online with GitHub Actions

The repository includes `.github/workflows/build-apk.yml`. After uploading the project files to a GitHub repository on the `main` branch, open the **Actions** tab and select **Build Foto2Excel APK** if needed, then press **Run workflow**. When the run finishes successfully, open the run and download the `Foto2Excel-debug-APK` artifact. Extract the downloaded ZIP to get `app-debug.apk`.

Note: this is a prototype. OCR uses ML Kit Latin text recognition; handwriting and complex table extraction may be inaccurate. The build has not yet been validated on a physical Android device.
