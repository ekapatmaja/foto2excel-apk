package id.foto2excel.app

import android.app.AlertDialog
import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var output: EditText
    private lateinit var status: TextView
    private lateinit var total: TextView
    private val prefs by lazy { getSharedPreferences("history", MODE_PRIVATE) }

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) runOcr(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Foto2Excel"
            textSize = 28f
            setTextColor(0xFF173B96.toInt())
            setPadding(0, 0, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "Ubah foto tulisan dan tabel menjadi data Excel"
            textSize = 14f
            setTextColor(0xFF5B6475.toInt())
        }
        root.addView(title)
        root.addView(subtitle)

        val pick = Button(this).apply {
            text = "Pilih gambar dari galeri"
            setOnClickListener { imagePicker.launch("image/*") }
        }
        root.addView(pick, matchWrap())

        status = TextView(this).apply {
            text = "Pilih foto yang berisi tulisan atau tabel. Periksa kembali hasil OCR sebelum ekspor."
            textSize = 14f
            setPadding(0, 12, 0, 8)
        }
        root.addView(status)

        output = EditText(this).apply {
            hint = "Hasil pembacaan akan muncul di sini. Edit jika ada angka atau tulisan yang keliru."
            gravity = android.view.Gravity.TOP
            minLines = 10
            textSize = 14f
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))

        val arrange = Button(this).apply {
            text = "Susun menjadi tabel kain"
            setOnClickListener { arrangeFabricData() }
        }
        root.addView(arrange, matchWrap())

        val calculate = Button(this).apply {
            text = "Hitung total yard"
            setOnClickListener { calculateTotals() }
        }
        root.addView(calculate, matchWrap())

        total = TextView(this).apply {
            text = "Total angka: —"
            textSize = 16f
            setTextColor(0xFF173B96.toInt())
            setPadding(0, 8, 0, 8)
        }
        root.addView(total)

        val export = Button(this).apply {
            text = "Ekspor ke Excel (.xlsx)"
            setOnClickListener { exportExcel() }
        }
        root.addView(export, matchWrap())

        val history = Button(this).apply {
            text = "Lihat riwayat konversi"
            setOnClickListener { showHistory() }
        }
        root.addView(history, matchWrap())

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 8 }

    private fun runOcr(uri: Uri) {
        status.text = "Sedang membaca gambar…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    output.setText(result.text)
                    status.text = if (result.text.isBlank()) {
                        "Belum ada tulisan yang terbaca. Coba gambar lebih terang dan tajam."
                    } else {
                        "Foto terbaca. Tekan 'Susun menjadi tabel kain', lalu periksa hasilnya."
                    }
                    saveHistory(result.text)
                    recognizer.close()
                }
                .addOnFailureListener { e ->
                    status.text = "Gagal membaca gambar: ${e.localizedMessage ?: "coba gambar lain"}"
                    recognizer.close()
                }
        } catch (e: Exception) {
            status.text = "Gambar tidak dapat dibuka: ${e.localizedMessage ?: "format tidak didukung"}"
        }
    }

    private fun arrangeFabricData() {
        val raw = output.text.toString()
        if (raw.isBlank()) {
            Toast.makeText(this, "Baca foto terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val rows = mutableListOf<Triple<String, String, String>>()
        var currentCode = ""
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        val codeRegex = Regex("(?i)\\b(BP[DJS]?\\s*\\d{1,5}|BP\\s*\\d{3,5})\\b")
        val itemRegex = Regex("(?i)^(.+?)\\s*[:：-]?\\s+(\\d{1,4})(?:\\s*(?:yard|yd))?\\s*$")
        for (line in lines) {
            val codeMatch = codeRegex.find(line)
            if (codeMatch != null && line.replace(codeMatch.value, "").trim().isEmpty()) {
                currentCode = codeMatch.value.replace(Regex("\\s+"), " ").uppercase(Locale("id", "ID"))
                continue
            }
            if (codeMatch != null) {
                currentCode = codeMatch.value.replace(Regex("\\s+"), " ").uppercase(Locale("id", "ID"))
                val remainder = line.replace(codeMatch.value, "").trim().trim(':', '-', ' ')
                val item = itemRegex.matchEntire(remainder)
                if (item != null) rows.add(Triple(currentCode, cleanColor(item.groupValues[1]), item.groupValues[2]))
                continue
            }
            val item = itemRegex.matchEntire(line)
            if (item != null && currentCode.isNotBlank()) {
                rows.add(Triple(currentCode, cleanColor(item.groupValues[1]), item.groupValues[2]))
            }
        }
        if (rows.isEmpty()) {
            status.text = "Belum bisa menyusun otomatis. Pastikan tiap kode kain dan warna/angka berada di baris terpisah; Anda tetap bisa mengedit teks secara manual."
            return
        }
        output.setText(buildString {
            append("Kode Kain\tWarna\tJumlah Yard\n")
            rows.forEach { (code, color, yard) -> append("$code\t$color\t$yard\n") }
        }.trimEnd())
        val grand = rows.sumOf { it.third.toDoubleOrNull() ?: 0.0 }
        status.text = "Tabel kain dibuat: ${rows.size} baris. Periksa kode, warna, dan angka sebelum ekspor."
        total.text = "Total yard sementara: ${formatNumber(grand)}"
    }

    private fun cleanColor(value: String): String = value
        .replace(Regex("(?i)\\b(yard|yd)\\b"), "")
        .replace(Regex("\\s+"), " ")
        .trim().trim(':', '-', ' ')

    private fun calculateTotals() {
        val lines = output.text.toString().lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            total.text = "Belum ada data."
            return
        }
        val headerPresent = lines.first().contains("Kode Kain", ignoreCase = true)
        val dataLines = if (headerPresent) lines.drop(1) else lines
        var sum = 0.0
        var count = 0
        dataLines.forEach { line ->
            val cells = splitLine(line)
            val yard = cells.getOrNull(2)?.let { parseNumber(it) }
            if (yard != null) { sum += yard; count++ }
        }
        total.text = if (count > 0) "Total yard: ${formatNumber(sum)} dari $count baris data"
        else "Tidak menemukan kolom Jumlah Yard. Tekan 'Susun menjadi tabel kain' terlebih dahulu."
    }

    private fun splitLine(line: String): List<String> {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return emptyList()
        return when {
            trimmed.contains('\t') -> trimmed.split('\t')
            trimmed.contains(';') -> trimmed.split(';')
            trimmed.contains('|') -> trimmed.split('|')
            trimmed.contains(',') -> trimmed.split(',')
            else -> trimmed.split(Regex("\\s{2,}"))
        }.map { it.trim() }
    }

    private fun parseNumber(raw: String): Double? {
        val s = raw.trim().replace("Rp", "", ignoreCase = true)
            .replace(" ", "").replace(".", "").replace(",", ".")
        return s.toDoubleOrNull()
    }

    private fun formatNumber(n: Double): String =
        String.format(Locale("id", "ID"), "%,.2f", n)

    private fun exportExcel() {
        val text = output.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "Pilih gambar atau masukkan data terlebih dahulu.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val workbook = XSSFWorkbook()
            val sheet = workbook.createSheet("Hasil Konversi")
            val lines = text.lines().filter { it.isNotBlank() }
            lines.forEachIndexed { rowIndex, line ->
                val row = sheet.createRow(rowIndex)
                splitLine(line).forEachIndexed { colIndex, value ->
                    row.createCell(colIndex).setCellValue(value)
                }
            }
            val header = workbook.createCellStyle().apply {
                val font = workbook.createFont().apply { bold = true }
                setFont(font)
            }
            if (lines.isNotEmpty()) {
                sheet.getRow(0)?.forEach { it.cellStyle = header }
            }
            val maxCols = lines.maxOfOrNull { splitLine(it).size } ?: 1
            for (i in 0 until maxCols.coerceAtMost(20)) sheet.setColumnWidth(i, 5000)

            val filename = "Foto2Excel_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.xlsx"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak dapat membuat file di folder Download")
            contentResolver.openOutputStream(uri)?.use { workbook.write(it) }
                ?: throw IllegalStateException("Tidak dapat menulis file Excel")
            workbook.close()
            saveHistory(text)
            status.text = "Excel tersimpan di folder Download: $filename"
            Toast.makeText(this, "Excel berhasil disimpan di Download", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "Ekspor gagal: ${e.localizedMessage ?: "kesalahan tidak diketahui"}"
        }
    }

    private fun saveHistory(value: String) {
        if (value.isBlank()) return
        val stamp = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("id", "ID")).format(Date())
        val old = prefs.getString("items", "") ?: ""
        val entry = "[$stamp]\n$value"
        prefs.edit().putString("items", (entry + "\n\n---\n\n" + old).take(30000)).apply()
    }

    private fun showHistory() {
        val history = prefs.getString("items", "")?.ifBlank { "Belum ada riwayat konversi." }
            ?: "Belum ada riwayat konversi."
        AlertDialog.Builder(this)
            .setTitle("Riwayat Konversi")
            .setMessage(history)
            .setPositiveButton("Tutup", null)
            .show()
    }
}
